hexo.extend.helper.register('argon_version', function () {
	return "1.0.1";
});